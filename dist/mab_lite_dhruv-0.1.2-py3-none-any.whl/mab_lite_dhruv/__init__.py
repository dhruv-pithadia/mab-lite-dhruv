from .multiarmbandit import pure_exploration, pure_exploitation
__all__ = ["pure_exploration", "pure_exploitation"]
__version__ = "0.1.2"